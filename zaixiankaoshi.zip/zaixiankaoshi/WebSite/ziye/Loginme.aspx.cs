﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using zaixiankaoshi.BLL;
using zaixiankaoshi.Models;

public partial class Account_Login1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {
       
    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        string loginid = txtLoginId.Text.Trim();
        string loginpwd = txtLoginPwd.Text.Trim();
        if (loginid.Length > 0 && loginpwd.Length > 0)
        {
            Users user = UsersManager.GetUsers(loginid);
            if (user ==null)
            {
                UsersManager.AddUser(loginid, loginpwd);
                Response.Redirect("Main.aspx");
            }
            else
            {
                if(loginpwd==user.Password.Trim())
                {
                    Response.Redirect("Main.aspx");
                }
                else
                {
                    lblMess.Text = "登录名或密码错误，请重新输入";                    
                }
            }            
        }
        else
        {
            lblMess.Text = "登录名或密码为空，请重新输入";
        }
    }
}
