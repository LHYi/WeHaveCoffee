﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using zaixiankaoshi.BLL;

public partial class userinformation : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        var user = UsersManager.GetUsers(CurrentUser.ID);
        LabelUserID.Text = user.UserID;
        ShowName.Text = user.UserName;
        ShowSchool.Text = user.School;
        ShowClass.Text = user.Class;
    }

    public static string newName;
    public static string newSchool;
    public static string newClass;
    public static string psw;
    public static string confirmpsw;

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {
        
    }

    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {

    }

    protected void TextBox5_TextChanged(object sender, EventArgs e)
    {

    }

    protected void ButtonID_Click(object sender, EventArgs e)
    {
        newName = TextBox1.Text.Trim();
        if (UsersManager.SetUserName(CurrentUser.ID, newName)==true)
        {
            LabelName.Text = "修改成功";
        }
        else
        {
            LabelName.Text = "修改失败";
        }
        ShowName.Text = newName;
    }

    protected void ButtonPsw_Click(object sender, EventArgs e)
    {
        psw = TextBox3.Text.Trim();
        confirmpsw = TextBox4.Text.Trim();
        if(psw==confirmpsw)
        {
            if (UsersManager.ResetPsw(CurrentUser.ID, psw) == true)
            {
                LabelPsw.Text = "修改成功";
            }
            else
            {
                LabelPsw.Text = "修改失败";
            }
        }
        else
        {
            LabelPsw.Text = "两次输入不匹配";
        }
    }

    protected void ButtonSchool_Click(object sender, EventArgs e)
    {
        newSchool = TextBox5.Text.Trim();
        if (UsersManager.SetUserSchool(CurrentUser.ID, newSchool) == true)
        {
            LabelSchool.Text = "修改成功";
        }
        else
        {
            LabelSchool.Text = "修改失败";
        }
        ShowSchool.Text = newSchool;
    }

    protected void ButtonClass_Click(object sender, EventArgs e)
    {
        newClass = TextBox6.Text.Trim();
        if (UsersManager.SetUserClass(CurrentUser.ID, newClass) == true)
        {
            LabelClass.Text = "修改成功";
        }
        else
        {
            LabelClass.Text = "修改失败";
        }
        ShowClass.Text = newClass;
    }
}