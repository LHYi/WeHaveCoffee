﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using zaixiankaoshi.BLL;
using zaixiankaoshi.Models;
public partial class dianlulilun : System.Web.UI.Page
{
    Questions[] ques = new Questions[10];
    Options[] options = new Options[10];
    string[] ABCD = new string[4] { "A", "B", "C", "D" };
    string[] choice = new string[10] { "A", "A", "A", "A", "A", "A", "A", "A", "A", "A"};
    string  hour1 = DateTime.Now.Hour.ToString();
    string  minute1 = DateTime.Now.Minute.ToString();
    string  second1 = DateTime.Now.Second.ToString();
    const H = DateTime.Now.Hour.ToString();


    protected void Page_Load(object sender, EventArgs e)
    {
        Label.Text = second1.ToString();
        Label.Text = second1.ToString();
        for (var i = 0; i < 10; i++)
        {
            ques[i] = QuestionsManager.GetQuestions(1001 + i);
            options[i] = OptionsManager.GetOptions(1001 + i);
        }
        ques1.Text = ques[0].Content;
        ques2.Text = ques[1].Content;
        ques3.Text = ques[2].Content;
        ques4.Text = ques[3].Content;
        ques5.Text = ques[4].Content;
        ques6.Text = ques[5].Content;
        ques7.Text = ques[6].Content;
        ques8.Text = ques[7].Content;
        ques9.Text = ques[8].Content;
        ques10.Text = ques[9].Content;
        list1.Items[0].Text = "A.   " + options[0].A;
        list1.Items[1].Text = "B.   " + options[0].B;
        list1.Items[2].Text = "C.   " + options[0].C;
        list1.Items[3].Text = "D.   " + options[0].D;
        list2.Items[0].Text = "A.   " + options[1].A;
        list2.Items[1].Text = "B.   " + options[1].B;
        list2.Items[2].Text = "C.   " + options[1].C;
        list2.Items[3].Text = "D.   " + options[1].D;
        list3.Items[0].Text = "A.   " + options[2].A;
        list3.Items[1].Text = "B.   " + options[2].B;
        list3.Items[2].Text = "C.   " + options[2].C;
        list3.Items[3].Text = "D.   " + options[2].D;
        list4.Items[0].Text = "A.   " + options[3].A;
        list4.Items[1].Text = "B.   " + options[3].B;
        list4.Items[2].Text = "C.   " + options[3].C;
        list4.Items[3].Text = "D.   " + options[3].D;
        list5.Items[0].Text = "A.   " + options[4].A;
        list5.Items[1].Text = "B.   " + options[4].B;
        list5.Items[2].Text = "C.   " + options[4].C;
        list5.Items[3].Text = "D.   " + options[4].D;
        list6.Items[0].Text = "A.   " + options[5].A;
        list6.Items[1].Text = "B.   " + options[5].B;
        list6.Items[2].Text = "C.   " + options[5].C;
        list6.Items[3].Text = "D.   " + options[5].D;
        list7.Items[0].Text = "A.   " + options[6].A;
        list7.Items[1].Text = "B.   " + options[6].B;
        list7.Items[2].Text = "C.   " + options[6].C;
        list7.Items[3].Text = "D.   " + options[6].D;
        list8.Items[0].Text = "A.   " + options[7].A;
        list8.Items[1].Text = "B.   " + options[7].B;
        list8.Items[2].Text = "C.   " + options[7].C;
        list8.Items[3].Text = "D.   " + options[7].D;
        list9.Items[0].Text = "A.   " + options[8].A;
        list9.Items[1].Text = "B.   " + options[8].B;
        list9.Items[2].Text = "C.   " + options[8].C;
        list9.Items[3].Text = "D.   " + options[8].D;
        list10.Items[0].Text = "A.   " + options[9].A;
        list10.Items[1].Text = "B.   " + options[9].B;
        list10.Items[2].Text = "C.   " + options[9].C;
        list10.Items[3].Text = "D.   " + options[9].D;

    }

    protected void list1_SelectedIndexChanged(object sender, EventArgs e)
    {
        for (int i = 0; i < 3; i++)
        {
            if (list1.SelectedItem == list1.Items[i])
            {
                choice[0] = ABCD[i];
            }
        }
    }
    protected void list2_SelectedIndexChanged(object sender, EventArgs e)
    {
        for (int i = 0; i < 3; i++)
        {
            if (list1.SelectedItem == list1.Items[i])
            {
                choice[1] = ABCD[i];
            }
        }
    }
    protected void list3_SelectedIndexChanged(object sender, EventArgs e)
    {
        for (int i = 0; i < 3; i++)
        {
            if (list1.SelectedItem == list1.Items[i])
            {
                choice[2] = ABCD[i];
            }
        }
    }
    protected void list4_SelectedIndexChanged(object sender, EventArgs e)
    {
        for (int i = 0; i < 3; i++)
        {
            if (list1.SelectedItem == list1.Items[i])
            {
                choice[3] = ABCD[i];
            }
        }
    }
    protected void list5_SelectedIndexChanged(object sender, EventArgs e)
    {
        for (int i = 0; i < 3; i++)
        {
            if (list1.SelectedItem == list1.Items[i])
            {
                choice[4] = ABCD[i];
            }
        }
    }
    protected void list6_SelectedIndexChanged(object sender, EventArgs e)
    {
        for (int i = 0; i < 3; i++)
        {
            if (list1.SelectedItem == list1.Items[i])
            {
                choice[5] = ABCD[i];
            }
        }
    }
    protected void list7_SelectedIndexChanged(object sender, EventArgs e)
    {
        for (int i = 0; i < 3; i++)
        {
            if (list1.SelectedItem == list1.Items[i])
            {
                choice[6] = ABCD[i];
            }
        }
    }
    protected void list8_SelectedIndexChanged(object sender, EventArgs e)
    {
        for (int i = 0; i < 3; i++)
        {
            if (list1.SelectedItem == list1.Items[i])
            {
                choice[7] = ABCD[i];
            }
        }
    }
    protected void list9_SelectedIndexChanged(object sender, EventArgs e)
    {
        for (int i = 0; i < 3; i++)
        {
            if (list1.SelectedItem == list1.Items[i])
            {
                choice[8] = ABCD[i];
            }
        }
    }
    protected void list10_SelectedIndexChanged(object sender, EventArgs e)
    {
        for (int i = 0; i < 3; i++)
        {
            if (list1.SelectedItem == list1.Items[i])
            {
                choice[9] = ABCD[i];
            }
        }
    }

    protected void Button_Click(object sender, EventArgs e)
    {
        int count = 0;
        for(int i = 0; i < 10; i++)
        {
            if(choice[i].Trim() != ques[i].Anwser.Trim())
            {
                count++;
            }
        }
        Button.Text = "做错了" + count + "道题目";
        answer1.Text = "正确答案是" + ques[0].Anwser;
        answer2.Text = "正确答案是" + ques[1].Anwser;
        answer3.Text = "正确答案是" + ques[2].Anwser;
        answer4.Text = "正确答案是" + ques[3].Anwser;
        answer5.Text = "正确答案是" + ques[4].Anwser;
        answer6.Text = "正确答案是" + ques[5].Anwser;
        answer7.Text = "正确答案是" + ques[6].Anwser;
        answer8.Text = "正确答案是" + ques[7].Anwser;
        answer9.Text = "正确答案是" + ques[8].Anwser;
        answer10.Text = "正确答案是" + ques[9].Anwser;
        string  hour2 = DateTime.Now.Hour.ToString();
        string  minute2 = DateTime.Now.Minute.ToString();
        string  second2 = DateTime.Now.Second.ToString();
        Label.Text = "start:"+ second1 + "end" + second2;
    }

    protected void Timer1_Tick(object sender, EventArgs e)
    {

    }

}
