﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using zaixiankaoshi.BLL;
using zaixiankaoshi.Models;
public partial class diannaolilun : System.Web.UI.Page
{
    Questions[] ques = new Questions[10];
    Options[] options = new Options[10];
    public static string[] ABCD = new string[4] { "A", "B", "C", "D" };
    public static string[] choice = new string[10] { "A", "A", "A", "A", "A", "A", "A", "A", "A", "A"};


    protected void Page_Load(object sender, EventArgs e)
    {
        for (var i = 0; i < 10; i++)
        {
            ques[i] = QuestionsManager.GetQuestions(1101 + i);
            options[i] = OptionsManager.GetOptions(1101 + i);
        }
        ques1.Text = ques[0].Content;
        ques2.Text = ques[1].Content;
        ques3.Text = ques[2].Content;
        ques4.Text = ques[3].Content;
        ques5.Text = ques[4].Content;
        ques6.Text = ques[5].Content;
        ques7.Text = ques[6].Content;
        ques8.Text = ques[7].Content;
        ques9.Text = ques[8].Content;
        ques10.Text = ques[9].Content;
        List10.Items[0].Text = options[0].A;
        List10.Items[1].Text = options[0].B;
        List10.Items[2].Text = options[0].C;
        List10.Items[3].Text = options[0].D;
        List12.Items[0].Text = options[1].A;
        List12.Items[1].Text = options[1].B;
        List12.Items[2].Text = options[1].C;
        List12.Items[3].Text = options[1].D;
        List13.Items[0].Text = options[2].A;
        List13.Items[1].Text = options[2].B;
        List13.Items[2].Text = options[2].C;
        List13.Items[3].Text = options[2].D;
        List14.Items[0].Text = options[3].A;
        List14.Items[1].Text = options[3].B;
        List14.Items[2].Text = options[3].C;
        List14.Items[3].Text = options[3].D;
        List15.Items[0].Text = options[4].A;
        List15.Items[1].Text = options[4].B;
        List15.Items[2].Text = options[4].C;
        List15.Items[3].Text = options[4].D;
        List16.Items[0].Text = options[5].A;
        List16.Items[1].Text = options[5].B;
        List16.Items[2].Text = options[5].C;
        List16.Items[3].Text = options[5].D;
        List17.Items[0].Text = options[6].A;
        List17.Items[1].Text = options[6].B;
        List17.Items[2].Text = options[6].C;
        List17.Items[3].Text = options[6].D;
        List18.Items[0].Text = options[7].A;
        List18.Items[1].Text = options[7].B;
        List18.Items[2].Text = options[7].C;
        List18.Items[3].Text = options[7].D;
        List19.Items[0].Text = options[8].A;
        List19.Items[1].Text = options[8].B;
        List19.Items[2].Text = options[8].C;
        List19.Items[3].Text = options[8].D;
        List20.Items[0].Text = options[9].A;
        List20.Items[1].Text = options[9].B;
        List20.Items[2].Text = options[9].C;
        List20.Items[3].Text = options[9].D;

    }

    protected void List10_SelectedIndexChanged(object sender, EventArgs e)
    {
        //Label.Text = List1.SelectedValue.ToString().Trim() + List1.Items[2].ToString().Trim();
        for (int i = 0; i < 4; i++)
        {
            if (List10.SelectedValue.ToString().Trim() == List10.Items[i].ToString().Trim())
            {
                diannaolilun.choice[0] = diannaolilun.ABCD[i];
            }
        }
    }
    protected void List12_SelectedIndexChanged(object sender, EventArgs e)
    {
        for (int i = 0; i < 4; i++)
        {
            if (List12.SelectedValue.ToString().Trim() == List12.Items[i].ToString().Trim())
            {
                diannaolilun.choice[1] = diannaolilun.ABCD[i];
            }
        }
    }

    protected void List13_SelectedIndexChanged(object sender, EventArgs e)
    {
        for (int i = 0; i < 4; i++)
        {
            if (List13.SelectedValue.ToString().Trim() == List13.Items[i].ToString().Trim())
            {
                diannaolilun.choice[2] = diannaolilun.ABCD[i];
            }
        }
    }

    protected void List14_SelectedIndexChanged(object sender, EventArgs e)
    {
        for (int i = 0; i < 4; i++)
        {
            if (List14.SelectedValue.ToString().Trim() == List14.Items[i].ToString().Trim())
            {
                diannaolilun.choice[3] = diannaolilun.ABCD[i];
            }
        }
    }

    protected void List15_SelectedIndexChanged1(object sender, EventArgs e)
    {
        for (int i = 0; i < 4; i++)
        {
            if (List15.SelectedValue.ToString().Trim() == List15.Items[i].ToString().Trim())
            {
                diannaolilun.choice[4] = diannaolilun.ABCD[i];
            }
        }
    }

    protected void List16_SelectedIndexChanged(object sender, EventArgs e)
    {
        for (int i = 0; i < 4; i++)
        {
            if (List16.SelectedValue.ToString().Trim() == List16.Items[i].ToString().Trim())
            {
                diannaolilun.choice[5] = diannaolilun.ABCD[i];
            }
        }
    }

    protected void List17_SelectedIndexChanged(object sender, EventArgs e)
    {
        for (int i = 0; i < 4; i++)
        {
            if (List17.SelectedValue.ToString().Trim() == List17.Items[i].ToString().Trim())
            {
                diannaolilun.choice[6] = diannaolilun.ABCD[i];
            }
        }
    }

    protected void List18_SelectedIndexChanged(object sender, EventArgs e)
    {
        for (int i = 0; i < 4; i++)
        {
            if (List18.SelectedValue.ToString().Trim() == List18.Items[i].ToString().Trim())
            {
                diannaolilun.choice[7] = diannaolilun.ABCD[i];
            }
        }
    }
    protected void List19_SelectedIndexChanged(object sender, EventArgs e)
    {
        for (int i = 0; i < 4; i++)
        {
            if (List19.SelectedValue.ToString().Trim() == List19.Items[i].ToString().Trim())
            {
                diannaolilun.choice[8] = diannaolilun.ABCD[i];
            }
        }
    }



    protected void Button_Click(object sender, EventArgs e)
    {
        int count = 0;
        for(int i = 0; i < 10; i++)
        {
            if(choice[i].Trim() != ques[i].Answer.Trim())
            {
                count++;
            }
        }
        Label.Text = "做错了" + count + "道题目";
        answer1.Text = "正确答案是" + ques[0].Answer + "你选择了" + choice[0];
        answer2.Text = "正确答案是" + ques[1].Answer + "你选择了" + choice[1];
        answer3.Text = "正确答案是" + ques[2].Answer + "你选择了" + choice[2];
        answer4.Text = "正确答案是" + ques[3].Answer + "你选择了" + choice[3];
        answer5.Text = "正确答案是" + ques[4].Answer + "你选择了" + choice[4];
        answer6.Text = "正确答案是" + ques[5].Answer + "你选择了" + choice[5];
        answer7.Text = "正确答案是" + ques[6].Answer + "你选择了" + choice[6];
        answer8.Text = "正确答案是" + ques[7].Answer + "你选择了" + choice[7];
        answer9.Text = "正确答案是" + ques[8].Answer + "你选择了" + choice[8];
        answer10.Text = "正确答案是" + ques[9].Answer + "你选择了" + choice[9];
    }



    protected void List20_SelectedIndexChanged(object sender, EventArgs e)
    {
        for (int i = 0; i < 4; i++)
        {
            if (List20.SelectedValue.ToString().Trim() == List20.Items[i].ToString().Trim())
            {
                diannaolilun.choice[9] = diannaolilun.ABCD[i];
            }
        }
    }

}

