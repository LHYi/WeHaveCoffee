﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using zaixiankaoshi.DAL;
using zaixiankaoshi.Models;

namespace zaixiankaoshi.BLL
{
    public  class UsersManager
    {
        public static void AddUser(string ID, string Psw)
        {
            UsersService.AddUser(ID, Psw);
            return;
        }

        public static Users GetUsers (string ID)
        {
            var Users = UsersService.GetUsers(ID);
            return Users;
        }
    }
}
