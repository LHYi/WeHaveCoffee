﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using zaixiankaoshi.DAL;
using zaixiankaoshi.Models;

namespace zaixiankaoshi.BLL
{
    public  class UsersManager
    {
        public static void AddUser(string ID, string Psw)
        {
            UsersService.AddUser(ID, Psw);
            return;
        }

        public static Users GetUsers (string ID)
        {
            var Users = UsersService.GetUsers(ID);
            return Users;
        }

        public static bool SetUserName(string ID, string Name)
        {
            if(UsersService.SetUserName(ID, Name)==true)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool SetUserSchool(string ID, string School)
        {
            if (UsersService.SetUserSchool(ID, School) == true)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool SetUserClass(string ID, string Class)
        {
            if (UsersService.SetUserClass(ID, Class) == true)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool ResetPsw(string ID, string Psw)
        {
            if (UsersService.ResetUserPsw(ID, Psw) == true)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

    }
}
