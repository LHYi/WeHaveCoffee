﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using zaixiankaoshi.DAL;
using zaixiankaoshi.Models;

namespace zaixiankaoshi.BLL
{
    public class QuestionsManager
    {
        public static Questions GetQuestions(int ID)
        {
            var Ques = QuestionsService.GetQues(ID);
            return Ques;
        }
    }
}
