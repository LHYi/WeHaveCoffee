﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zaixiankaoshi.BLL
{
    public class PaperManager
    {
        public static int[] RandomGetPaper(int CourseID)
        {
            int[] QuesID = new int[10];
            long tick = DateTime.Now.Ticks;
            Random random = new Random((int)tick );
            for (int i = 1; i < 6; )
            {
                
                int rand = random.Next(1, 11) + CourseID * 1000 + 100;
                if (Array.IndexOf(QuesID,rand)==-1)    //数组中不存在
                {
                    QuesID[i-1] = rand;
                    i++;
                }
                else
                {
                    continue;
                }
            }
            for (int i = 6; i < 11; )
            {
                int  rand = random.Next(1, 11) + CourseID * 1000 + 200;
                if (Array.IndexOf(QuesID, rand) == -1)
                {
                    QuesID[i - 1] = rand;
                    i++;
                }
                else
                {
                    continue;
                }
            }
            return QuesID;
        }
    }
}
