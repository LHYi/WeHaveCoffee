﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using zaixiankaoshi.DAL;
using zaixiankaoshi.Models;

namespace zaixiankaoshi.BLL
{
    public class OptionsManager
    {
        public static Options GetOptions(int QuesID)
        {
            var options = OptionsService.GetOptions(QuesID);
            return options;
        }
    }
}
