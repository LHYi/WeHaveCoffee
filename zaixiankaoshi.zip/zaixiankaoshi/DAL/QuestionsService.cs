﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using zaixiankaoshi.Models;

namespace zaixiankaoshi.DAL
{
    public class QuestionsService
    {
        public static Questions GetQues(int QuesID)
        {
            WeHaveCoffeeEntities dbcontext = new WeHaveCoffeeEntities();
            var  Ques = dbcontext.Questions.Find(QuesID);
            return Ques;
        }
    }
}
