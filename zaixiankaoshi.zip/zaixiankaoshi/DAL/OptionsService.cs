﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using zaixiankaoshi.Models;

namespace zaixiankaoshi.DAL
{
    public class OptionsService
    {
        public static Options GetOptions(int QuesID)
        {
            WeHaveCoffeeEntities dbcontext = new WeHaveCoffeeEntities();
            var Options = dbcontext.Options.Find(QuesID);
            return Options;
        }
    }
}
