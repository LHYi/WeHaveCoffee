﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using zaixiankaoshi.Models;

namespace zaixiankaoshi.DAL
{
    public  class UsersService
    {
        public static void AddUser(string ID, string Psw)
        {
            WeHaveCoffeeEntities dbcontext = new WeHaveCoffeeEntities();
            dbcontext.Users.Add(new Users() { UserID = ID, UserName = "User", Password = Psw, School = "HUST", Class = "SEEE1601", Role = "Student", QuestionCount = 0, RightCount = 0, TotalScore = 0 });
            dbcontext.SaveChanges();
            return;
        }

        public static void SetUserName(string ID, string Name)
        {
            WeHaveCoffeeEntities dbcontext = new WeHaveCoffeeEntities();
            var user = dbcontext.Users.Find(ID);
            user.UserName = Name;
            dbcontext.SaveChanges();
        }

        public static void SetUserSchool(string ID, string School)
        {
            WeHaveCoffeeEntities dbcontext = new WeHaveCoffeeEntities();
            var user = dbcontext.Users.Find(ID);
            user.School = School;
            dbcontext.SaveChanges();
        }

        public static void SetUserClass(string ID, string Class)
        {
            WeHaveCoffeeEntities dbcontext = new WeHaveCoffeeEntities();
            var user = dbcontext.Users.Find(ID);
            user.Class = Class;
            dbcontext.SaveChanges();
        }

        public static void SetUserRole(string ID, string Role)
        {
            WeHaveCoffeeEntities dbcontext = new WeHaveCoffeeEntities();
            var user = dbcontext.Users.Find(ID);
            user.Role = Role;
            dbcontext.SaveChanges();
        }

        public static void UpdateQuesCount(string ID, int count)
        {
            WeHaveCoffeeEntities dbcontext = new WeHaveCoffeeEntities();
            var user = dbcontext.Users.Find(ID);
            user.QuestionCount += count;
            dbcontext.SaveChanges();
        }

        public static void UpdateRightCount(string ID, int count)
        {
            WeHaveCoffeeEntities dbcontext = new WeHaveCoffeeEntities();
            var user = dbcontext.Users.Find(ID);
            user.RightCount += count;
            dbcontext.SaveChanges();
        }

        public static void UpdateScore(string ID)
        {
            WeHaveCoffeeEntities dbcontext = new WeHaveCoffeeEntities();
            var user = dbcontext.Users.Find(ID);
            user.TotalScore = user.RightCount / user.QuestionCount;
        }

        public static void DeleteUser(string ID)
        {
            WeHaveCoffeeEntities dbcontext = new WeHaveCoffeeEntities();
            var course = dbcontext.Courses.Find(ID);
            dbcontext.Courses.Remove(course);
            dbcontext.SaveChanges();
            return;
        }

        public static Users GetUsers(string  ID)
        {
            WeHaveCoffeeEntities dbcontext = new WeHaveCoffeeEntities();
            var user = dbcontext.Users.Find(ID);
            return user;
        }
    
}
}
